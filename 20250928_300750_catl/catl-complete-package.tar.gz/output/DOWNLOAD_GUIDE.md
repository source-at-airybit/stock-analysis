# 宁德时代投资分析网站 - 下载和部署指南

## 📦 **项目下载**

### **完整项目包下载**
📥 **[下载完整项目包](https://uc5yclynmaysq.ok.kimi.link/catl-investment-analysis.tar.gz)**

文件大小: ~2.6MB
包含所有HTML、CSS、JS、图片和部署脚本

### **单独文件下载**
如果您只需要特定文件，可以单独下载：

📄 **[下载 index.html (主页)](https://uc5yclynmaysq.ok.kimi.link/index.html)**  
📄 **[下载 analysis.html (分析页)](https://uc5yclynmaysq.ok.kimi.link/analysis.html)**  
📄 **[下载 investment.html (投资页)](https://uc5yclynmaysq.ok.kimi.link/investment.html)**  
📄 **[下载 main.js (脚本文件)](https://uc5yclynmaysq.ok.kimi.link/main.js)**  
📄 **[下载 README.md (说明文档)](https://uc5yclynmaysq.ok.kimi.link/README.md)**  

🖼️ **[下载图片资源](https://uc5yclynmaysq.ok.kimi.link/)**
- hero-bg.png (背景图片)
- battery-tech.png (技术图片)
- data-viz.png (数据可视化图片)

## 🚀 **快速部署**

### **方法1：一键部署（推荐）**

**Linux/Mac用户：**
```bash
# 下载并运行部署脚本
wget https://uc5yclynmaysq.ok.kimi.link/deploy.sh
chmod +x deploy.sh
./deploy.sh
```

**Windows用户：**
```cmd
# 下载并运行部署脚本
# 下载 deploy.bat 文件后双击运行
```

### **方法2：手动部署**

**步骤1：下载项目文件**
```bash
# 创建项目目录
mkdir catl-investment-analysis
cd catl-investment-analysis

# 下载所有文件
wget https://uc5yclynmaysq.ok.kimi.link/index.html
wget https://uc5yclynmaysq.ok.kimi.link/analysis.html
wget https://uc5yclynmaysq.ok.kimi.link/investment.html
wget https://uc5yclynmaysq.ok.kimi.link/main.js
wget https://uc5yclynmaysq.ok.kimi.link/hero-bg.png
wget https://uc5yclynmaysq.ok.kimi.link/battery-tech.png
wget https://uc5yclynmaysq.ok.kimi.link/data-viz.png
```

**步骤2：启动本地服务器**
```bash
# 使用Python（推荐）
python -m http.server 8000

# 或使用Node.js
npx serve .

# 或使用PHP
php -S localhost:8000
```

**步骤3：访问网站**
打开浏览器访问：`http://localhost:8000`

## 📋 **部署选项**

### **本地开发**
- ✅ Python内置服务器 (`python -m http.server 8000`)
- ✅ Node.js serve包 (`npx serve .`)
- ✅ PHP内置服务器 (`php -S localhost:8000`)
- ✅ Live Server插件 (VS Code)

### **生产环境**
- ✅ Nginx
- ✅ Apache
- ✅ IIS (Windows服务器)
- ✅ Docker容器

### **静态网站托管**
- ✅ GitHub Pages (免费)
- ✅ Netlify (免费额度)
- ✅ Vercel (免费额度)
- ✅ 阿里云OSS
- ✅ 腾讯云COS

## 🛠️ **技术要求和兼容性**

### **系统要求**
- 操作系统: Windows 7+, macOS 10.10+, Linux
- 内存: 512MB+
- 存储: 10MB+

### **浏览器兼容性**
- Chrome 60+
- Firefox 60+
- Safari 12+
- Edge 79+
- 移动端浏览器

### **服务器要求**
- 任何支持静态文件的Web服务器
- 推荐启用GZIP压缩
- 推荐启用HTTPS

## 📊 **项目结构**
```
catl-investment-analysis/
├── index.html          # 主页 - 概览和核心指标
├── analysis.html       # 深度分析页面
├── investment.html     # 投资策略页面
├── main.js            # 主要JavaScript文件
├── hero-bg.png        # 背景图片
├── battery-tech.png   # 电池技术图片
├── data-viz.png       # 数据可视化图片
├── README.md          # 项目说明文档
├── deploy.sh          # Linux/Mac部署脚本
├── deploy.bat         # Windows部署脚本
└── package.json       # Node.js项目配置
```

## 🎯 **核心功能**

### **主页 (index.html)**
- 宁德时代品牌展示
- 实时股价和核心财务指标
- 全球动力电池市场份额图表
- 投资建议摘要

### **深度分析 (analysis.html)**
- 财务表现趋势分析
- 竞争对手对比
- 技术优势评估
- 政策影响分析

### **投资策略 (investment.html)**
- 风险评估
- 具体投资建议
- 止盈止损位设置
- 收益计算器
- 3个月交易计划

## 💡 **投资建议核心数据**

- **综合评级**: 买入
- **当前价位**: ¥380
- **3个月目标价**: ¥420-450
- **止损位**: ¥320
- **预期涨幅**: 15-25%
- **风险等级**: 中等

## 🔧 **自定义配置**

### **修改数据**
在 `main.js` 文件中更新财务数据：
```javascript
const financialData = {
    revenue: 3620,    // 营收(亿元)
    profit: 507,      // 净利润(亿元)
    marketShare: 37.9 // 市场份额(%)
};
```

### **修改样式**
在CSS中修改主题颜色：
```css
:root {
    --primary-color: #1e3a8a;
    --secondary-color: #f59e0b;
    --success-color: #10b981;
}
```

## ⚠️ **重要提醒**

1. **投资建议仅供参考**，不构成投资承诺
2. **投资有风险**，入市需谨慎
3. 基于公开数据分析，数据可能存在延迟
4. 请根据个人风险承受能力做出投资决策
5. 建议在专业投资顾问指导下进行投资

## 🌐 **在线演示**

您可以先访问在线版本体验完整功能：
**https://uc5yclynmaysq.ok.kimi.link**

## 📞 **技术支持**

如果在部署过程中遇到问题：

1. 检查文件是否完整下载
2. 确保所有文件在同一目录下
3. 查看浏览器控制台错误信息
4. 确认本地服务器正常运行
5. 检查防火墙设置

## 📄 **许可证**

本项目采用 MIT 许可证。

---

**享受您的投资分析之旅！** 📈✨