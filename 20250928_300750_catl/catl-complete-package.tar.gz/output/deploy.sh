#!/bin/bash

# 宁德时代投资分析网站部署脚本
# 支持多种部署方式：本地、服务器、Docker等

set -e

echo "🚀 宁德时代投资分析网站部署工具"
echo "======================================"

# 检查系统类型
OS="$(uname -s)"
case "${OS}" in
    Linux*)     MACHINE=Linux;;
    Darwin*)    MACHINE=Mac;;
    CYGWIN*)    MACHINE=Cygwin;;
    MINGW*)     MACHINE=MinGw;;
    *)          MACHINE="UNKNOWN:${OS}"
esac

echo "检测到系统: ${MACHINE}"
echo ""

# 显示部署选项
echo "请选择部署方式:"
echo "1) 本地开发服务器 (推荐)"
echo "2) 生产环境部署"
echo "3) Docker容器部署"
echo "4) 静态网站托管"
echo "5) 下载项目文件"
echo ""

read -p "请输入选项 (1-5): " choice

case $choice in
    1)
        echo "🖥️  本地开发服务器部署"
        echo "======================"
        
        # 检查Python
        if command -v python3 &> /dev/null; then
            echo "✅ 检测到Python3"
            echo "启动本地服务器..."
            echo "访问地址: http://localhost:8000"
            echo "按 Ctrl+C 停止服务器"
            python3 -m http.server 8000
        elif command -v python &> /dev/null; then
            echo "✅ 检测到Python2"
            echo "启动本地服务器..."
            echo "访问地址: http://localhost:8000"
            echo "按 Ctrl+C 停止服务器"
            python -m SimpleHTTPServer 8000
        elif command -v node &> /dev/null; then
            echo "✅ 检测到Node.js"
            if ! command -v serve &> /dev/null; then
                echo "安装serve..."
                npm install -g serve
            fi
            echo "启动本地服务器..."
            echo "访问地址: http://localhost:3000"
            echo "按 Ctrl+C 停止服务器"
            serve -p 3000
        else
            echo "❌ 未检测到Python或Node.js"
            echo "请先安装Python3或Node.js"
            exit 1
        fi
        ;;
    
    2)
        echo "🏭 生产环境部署"
        echo "=============="
        echo "此选项用于在Linux服务器上部署网站"
        echo ""
        
        read -p "请输入网站域名(如: example.com): " domain
        read -p "请输入部署目录(如: /var/www/html): " deploy_dir
        
        if [ -z "$domain" ] || [ -z "$deploy_dir" ]; then
            echo "❌ 域名和部署目录不能为空"
            exit 1
        fi
        
        echo "部署配置:"
        echo "域名: $domain"
        echo "目录: $deploy_dir"
        echo ""
        
        # 创建部署目录
        sudo mkdir -p "$deploy_dir"
        
        # 复制文件
        echo "复制文件到部署目录..."
        sudo cp -r ./* "$deploy_dir/"
        sudo chown -R www-data:www-data "$deploy_dir"
        
        # 创建Nginx配置
        echo "创建Nginx配置..."
        sudo tee /etc/nginx/sites-available/catl-analysis > /dev/null <<EOF
server {
    listen 80;
    server_name $domain;
    root $deploy_dir;
    index index.html;
    
    location / {
        try_files \$uri \$uri/ /index.html;
    }
    
    # 静态资源缓存
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    
    # 安全头
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
}
EOF
        
        # 启用站点
        sudo ln -sf /etc/nginx/sites-available/catl-analysis /etc/nginx/sites-enabled/
        sudo nginx -t && sudo systemctl reload nginx
        
        echo "✅ 部署完成！"
        echo "访问地址: http://$domain"
        ;;
    
    3)
        echo "🐳 Docker容器部署"
        echo "=================="
        
        if ! command -v docker &> /dev/null; then
            echo "❌ 未检测到Docker"
            echo "请先安装Docker: https://docs.docker.com/get-docker/"
            exit 1
        fi
        
        # 创建Dockerfile
        cat > Dockerfile <<EOF
FROM nginx:alpine
COPY . /usr/share/nginx/html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
EOF
        
        # 构建镜像
        echo "构建Docker镜像..."
        docker build -t catl-investment-analysis .
        
        # 运行容器
        echo "启动Docker容器..."
        echo "访问地址: http://localhost:8080"
        echo "按 Ctrl+C 停止容器"
        docker run -p 8080:80 catl-investment-analysis
        ;;
    
    4)
        echo "🌐 静态网站托管"
        echo "==============="
        echo "支持以下平台:"
        echo "1) GitHub Pages"
        echo "2) Netlify"
        echo "3) Vercel"
        echo "4) 阿里云OSS"
        echo ""
        echo "部署步骤:"
        echo "1. 将项目文件上传到选择的平台"
        echo "2. 配置域名和HTTPS"
        echo "3. 启用CDN加速(可选)"
        echo ""
        echo "详细指南请查看 README.md"
        ;;
    
    5)
        echo "💾 下载项目文件"
        echo "=============="
        echo "项目文件已准备就绪:"
        echo "- index.html (主页)"
        echo "- analysis.html (深度分析)"
        echo "- investment.html (投资策略)"
        echo "- main.js (主要脚本)"
        echo "- README.md (项目说明)"
        echo "- hero-bg.png (背景图片)"
        echo "- battery-tech.png (技术图片)"
        echo "- data-viz.png (数据可视化图片)"
        echo ""
        echo "使用方法:"
        echo "1. 将所有文件放在同一目录"
        echo "2. 运行本地服务器"
        echo "3. 访问 http://localhost:8000"
        ;;
    
    *)
        echo "❌ 无效的选项"
        exit 1
        ;;
esac