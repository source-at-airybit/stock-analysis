# 宁德时代投资分析网站

## 项目概述
这是一个专业的金融投资分析网站，专注于宁德时代（CATL）的深度投资分析。网站提供实时数据分析、竞争对手对比、政策影响评估和具体的投资建议。

## 功能特性
- 📊 实时股价数据展示
- 📈 交互式财务图表
- 🏢 竞争对手分析
- 📋 政策影响评估
- 💰 投资收益计算器
- 📱 响应式设计
- 🎨 现代化UI界面

## 技术栈
- **前端**: HTML5, CSS3, JavaScript (ES6+)
- **样式框架**: Tailwind CSS
- **图表库**: ECharts.js
- **动画库**: Anime.js
- **字体**: Noto Sans SC, Noto Serif SC

## 快速开始

### 方法一：直接下载使用（推荐）
1. **下载项目文件**
   ```bash
   # 创建项目目录
   mkdir catl-investment-analysis
   cd catl-investment-analysis
   
   # 下载所有文件
   wget https://uc5yclynmaysq.ok.kimi.link/index.html
   wget https://uc5yclynmaysq.ok.kimi.link/analysis.html
   wget https://uc5yclynmaysq.ok.kimi.link/investment.html
   wget https://uc5yclynmaysq.ok.kimi.link/main.js
   ```

2. **本地运行**
   ```bash
   # 使用Python启动本地服务器
   python -m http.server 8000
   
   # 或使用Node.js
   npx serve .
   
   # 或使用PHP
   php -S localhost:8000
   ```

3. **访问网站**
   打开浏览器访问 `http://localhost:8000`

### 方法二：Git克隆部署
```bash
# 克隆项目（如果有Git仓库）
git clone [项目地址]
cd catl-investment-analysis

# 安装依赖
npm install

# 启动开发服务器
npm start

# 构建生产版本
npm run build
```

### 方法三：Docker部署
```dockerfile
# Dockerfile
FROM nginx:alpine
COPY . /usr/share/nginx/html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

```bash
# 构建镜像
docker build -t catl-analysis .

# 运行容器
docker run -p 8080:80 catl-analysis
```

## 文件结构
```
catl-investment-analysis/
├── index.html          # 主页 - 概览和核心指标
├── analysis.html       # 深度分析页面
├── investment.html     # 投资策略页面
├── main.js            # 主要JavaScript文件
├── hero-bg.png        # 背景图片
├── battery-tech.png   # 电池技术图片
├── data-viz.png       # 数据可视化图片
└── README.md          # 项目说明
```

## 页面说明

### 主页 (index.html)
- **Hero区域**: 宁德时代品牌展示
- **核心指标**: 营收、利润、市场份额等关键数据
- **市场地位**: 全球动力电池市场份额图表
- **投资建议摘要**: 买入评级和目标价位

### 深度分析页面 (analysis.html)
- **财务分析**: 营收、利润、毛利率趋势
- **竞争对手对比**: 与比亚迪、LG新能源等对比
- **技术优势分析**: 电池技术、专利布局
- **政策影响评估**: 国内外新能源政策影响

### 投资策略页面 (investment.html)
- **风险评估**: 市场风险、技术风险、政策风险
- **投资建议**: 具体买入策略、仓位管理
- **止盈止损位**: 3个月内的具体操作点位
- **长期展望**: 未来1-3年发展前景

## 投资建议摘要
- **综合评级**: 买入
- **3个月目标价**: ¥420-450
- **预期涨幅**: 15-25%
- **止损位**: ¥320
- **风险等级**: 中等

## 自定义配置

### 修改颜色主题
在CSS中修改CSS变量：
```css
:root {
    --primary-color: #1e3a8a;
    --secondary-color: #f59e0b;
    --success-color: #10b981;
    --background-color: #f8fafc;
}
```

### 添加新图表
使用ECharts添加新的数据可视化：
```javascript
const chart = echarts.init(document.getElementById('newChart'));
const option = {
    // 图表配置
};
chart.setOption(option);
```

### 更新数据
在JavaScript文件中更新财务数据和市场数据：
```javascript
const financialData = {
    revenue: 3620, // 亿元
    profit: 507,   // 亿元
    margin: 24.4   // %
};
```

## 部署选项

### 静态网站托管
- **GitHub Pages**: 免费，适合开源项目
- **Netlify**: 免费额度充足，支持自动部署
- **Vercel**: 高性能，适合现代前端项目
- **阿里云OSS**: 国内访问速度快

### 服务器部署
- **Nginx**: 高性能Web服务器
- **Apache**: 传统Web服务器
- **Caddy**: 自动HTTPS，配置简单

### CDN加速
- **Cloudflare**: 免费CDN服务
- **阿里云CDN**: 国内加速效果好
- **腾讯云CDN**: 与云服务集成度高

## 浏览器兼容性
- Chrome 60+
- Firefox 60+
- Safari 12+
- Edge 79+
- 移动端浏览器

## 性能优化
- 图片懒加载
- CSS和JS文件压缩
- 启用GZIP压缩
- 使用CDN加速静态资源
- 浏览器缓存策略

## 安全建议
- 使用HTTPS协议
- 设置Content Security Policy
- 定期更新依赖库
- 限制跨域请求
- 输入数据验证

## 维护和更新
- 定期更新财务数据
- 监控网站性能
- 备份重要数据
- 更新安全补丁
- 优化用户体验

## 联系方式
如有问题或建议，请通过以下方式联系：
- 邮箱: [your-email@example.com]
- GitHub: [your-github-username]

## 免责声明
本网站提供的投资建议仅供参考，不构成投资建议。投资有风险，入市需谨慎。请根据自己的风险承受能力和投资目标做出决策。

## 许可证
本项目采用 MIT 许可证。详情请查看 LICENSE 文件。

---

**注意**: 本项目是一个静态网站，不需要复杂的编译过程。所有文件都是可以直接在浏览器中运行的HTML、CSS和JavaScript文件。部署时只需要将这些文件放在Web服务器上即可。